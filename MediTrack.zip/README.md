# MediTrack – Full-Stack Healthcare Management System

MediTrack is a comprehensive, professional, and responsive hospital management system. It provides real-time clinical workflows, electronic medical records, specialist scheduling, patient admissions, pharmacy inventory, and automated billing.

---

## 1. Quick Start – Standalone Frontend (Zero Dependencies)

> **Important:** The frontend is completely independent and requires **no** terminal commands, no Node.js, and no build tools to view or use.

1. Locate `index.html` in the `MediTrack/` folder.
2. **Double-click `index.html`** or open it directly in Google Chrome / any modern browser.
3. The complete MediTrack hospital portal will load immediately with all functional modules, populated clinical seed records, search filters, modals, and pure SVG charts.
4. All CRUD operations (adding patients, booking appointments, updating stock, creating bills, generating diagnostic records) persist instantly in your browser's LocalStorage.

---

## 2. Full-Stack Setup (Node.js + MySQL Backend)

When you wish to run the full-stack system with a centralized MySQL database:

### Step 1: Database Setup
1. Ensure **MySQL Server** (or XAMPP / WampServer / MariaDB) is installed and running.
2. Open MySQL CLI or phpMyAdmin:
   ```bash
   mysql -u root -p < database/meditrack.sql
   ```
   This creates the database `meditrack` and all tables with comprehensive seed data.

### Step 2: Configure Environment
1. Navigate to the `backend/` directory:
   ```bash
   cd backend
   ```
2. Copy `.env.example` to `.env`:
   ```bash
   cp .env.example .env
   ```
3. Update your database credentials in `.env`:
   ```env
   PORT=5000
   DB_HOST=localhost
   DB_USER=root
   DB_PASSWORD=your_password
   DB_NAME=meditrack
   DB_PORT=3306
   ```

### Step 3: Start the Backend Server
```bash
cd backend
npm install
npm start
```
The server will boot on `http://localhost:5000`.

### Step 4: Open Frontend
Open `index.html` in your browser. The frontend automatically detects the active backend at `http://localhost:5000/api` and displays the **🟢 Node.js / MySQL Live** badge in the sidebar!

---

## 3. Project Structure

```
MediTrack/
├── index.html              # Clinical Overview Dashboard (Charts, KPIs, Bed Matrix)
├── login.html              # Staff Authentication & Portal (1-click demo logins)
├── patients.html           # Patient Management (Registration, Vitals, Profiles)
├── doctors.html            # Medical Specialists Roster & Live Availability
├── appointments.html       # Scheduling, Rescheduling & Consultation Slips
├── medical-records.html    # Electronic Health Records (EHR, Diagnoses, Prescriptions)
├── medicines.html          # Pharmacy & Drug Inventory with Low-Stock Alerts
├── billing.html            # Patient Billing, Itemized Invoices & Print PDF
├── css/
│   ├── style.css           # Clinical Blue & White theme, components, print styles
│   └── responsive.css      # Tablet and mobile viewport breakpoints
├── js/
│   ├── store.js            # Standalone LocalStorage database & seed data
│   ├── api.js              # REST API bridge with auto-detection
│   ├── app.js              # UI controller (toasts, modals, mobile drawer, ZIP download)
│   ├── dashboard.js        # Pure SVG charts, bed matrix, today's queue
│   ├── patients.js         # Patient directory CRUD & medical charts
│   ├── doctors.js          # Doctor roster & availability status toggle
│   ├── appointments.js     # Scheduling & consultation pass generator
│   ├── medical-records.js  # Clinical encounters & multi-item prescription manager
│   ├── medicines.js        # Pharmacy inventory, restock modal, expiry audit
│   ├── billing.js          # Tax invoice generator, dynamic services, PDF print
│   └── auth.js             # Staff session manager & role switching
├── backend/
│   ├── server.js           # Express.js REST API server
│   ├── config/db.js        # MySQL connection pool
│   ├── controllers/        # CRUD controller logic for all entities
│   ├── routes/             # REST route endpoints
│   ├── package.json        # Backend dependencies
│   └── .env.example        # Environment configuration template
├── database/
│   └── meditrack.sql       # Complete MySQL schema & realistic clinical seed data
└── README.md
```

---

## 4. Main Modules & Features

| Module | Features Included |
| :--- | :--- |
| **Dashboard** | Total patients, active specialists, today's schedule, available beds, collected revenue, pure SVG admission trends chart, department breakdown donut, live clinical activity feed. |
| **Patients** | Register new patients, patient code generation, detailed clinical chart with vitals (BP, pulse, temp, SpO2), medical conditions, edit/delete records, live search & filters. |
| **Doctors** | Medical specialty cards, qualification, consultation fees, duty schedule, live availability status toggle (`Available`, `In Surgery`, `Busy`, `On Leave`), add/edit doctor profiles. |
| **Appointments** | Patient appointment booking, rescheduling modal, cancellation, mark as completed, printable outpatient consultation pass, date/status filtering. |
| **Medical Records** | Electronic Health Records (EHR), presenting symptoms, diagnoses (ICD-10 style), dynamic multi-item prescription manager (dosage, frequency, duration), printable clinical report. |
| **Pharmacy / Medicines**| Pharmaceutical stock inventory, low-stock threshold warning banner, expiry date tracker (60-day warning), quick restock modal (+/- units), add/edit medicine. |
| **Billing & Invoices** | Itemized invoice generator, dynamic services list, automatic subtotal, tax %, discount calculation, payment status tracking (`Paid`, `Pending`, `Partially Paid`), printable official invoice. |
| **Staff Portal** | Role-based authentication with 1-click demo logins: Doctor (CMO), Hospital Administrator, Reception Desk; staff registration modal. |

---

## 5. REST API Endpoints Reference

- `GET /api/health` — Backend server health status
- `GET /api/patients` — List all registered patients
- `POST /api/patients` — Register a new patient
- `PUT /api/patients/:id` — Update patient information
- `DELETE /api/patients/:id` — Remove patient record
- `GET /api/doctors` — List all medical specialists
- `POST /api/doctors` — Add a new doctor
- `PATCH /api/doctors/:id/availability` — Toggle doctor availability status
- `GET /api/appointments` — List all scheduled appointments
- `POST /api/appointments` — Book an appointment
- `PATCH /api/appointments/:id/reschedule` — Reschedule appointment date/time
- `PATCH /api/appointments/:id/status` — Update appointment status
- `GET /api/medical-records` — List clinical records and diagnoses
- `POST /api/medical-records` — File a new medical encounter
- `GET /api/medicines` — Retrieve pharmacy inventory
- `POST /api/medicines` — Add new pharmaceutical drug
- `PATCH /api/medicines/:id/stock` — Adjust stock quantity
- `GET /api/billing` — Retrieve all patient invoices
- `POST /api/billing` — Generate a new invoice
- `PATCH /api/billing/:id/status` — Mark invoice as paid / update payment method
- `POST /api/auth/login` — Staff sign in
- `POST /api/auth/register` — Register staff account
